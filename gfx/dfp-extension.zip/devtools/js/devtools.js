(function() {
    "use strict";

    chrome.devtools.panels.create("DFP Console",
        null,
        "devtools/panel.html",
        null);
}());